package com.youfan.kafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by Administrator on 2018/10/14 0014.
 */
@SpringBootApplication
public class Dsapplicationstart {

    public static void main(String[] args) {
        SpringApplication.run(Dsapplicationstart.class,args);
    }
}
